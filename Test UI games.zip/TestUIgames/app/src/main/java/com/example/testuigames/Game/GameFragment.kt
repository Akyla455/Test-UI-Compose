package com.example.testuigames.Game

import android.app.Fragment
import com.example.testuigames.ViewModel.GameViewModel
import androidx.fragment.app.activityViewModels

class GameFragment: Fragment() {
    private val viewModel: GameViewModel by activityViewModels()
}